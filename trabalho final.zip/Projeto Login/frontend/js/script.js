document.addEventListener("DOMContentLoaded", () => {

    const btn = document.getElementById("btnTema");
    const body = document.body;
    const formLogin = document.getElementById("formLogin");
    const formCadastro = document.getElementById("formCadastro");
    const formAtualizar = document.getElementById("formAtualizar");


    const temaInicial = window.matchMedia('(prefers-color-scheme: dark)').matches;
    body.classList.add(temaInicial ? 'dark' : 'light');

    btn.addEventListener("click", () => {
        body.classList.toggle('light');
        body.classList.toggle('dark');
    });

    if (formLogin) {
        formLogin.addEventListener("submit", async (e) => {
            e.preventDefault();

            const email = document.getElementById("email").value;
            const senha = document.getElementById("senha").value;

            try {
                const res = await fetch('http://localhost:3000/login', {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email, senha })
                });

                const data = await res.json();
                if (res.status === 200) {
                    localStorage.setItem("userEmail", email);
                    alert(`OK: ${data.mensagem}`);
                    window.location.href = "../cartaz.html";
                } else {
                    alert(`ERROR: ${data.mensagem}`);
                }
            } catch (error) {
                alert("Erro");
                console.error(error);
            }
        });
    }

    if (formCadastro) {
        formCadastro.addEventListener("submit", async (e) => {
            e.preventDefault();

            const email = document.getElementById("email").value;
            const senha = document.getElementById("senha").value;

            try {
                const res = await fetch('http://localhost:3000/cadastrar', {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ email, senha })
                });

                const data = await res.json();
                if (res.status === 201) {
                    alert(`OK: ${data.mensagem}`);
                    window.location.href = "../index.html";
                } else {
                    alert(`ERROR: ${data.mensagem}`);
                }
            } catch (error) {
                alert("Erro");
                console.error(error);
            }
        });
    }

    const userEmail = localStorage.getItem("userEmail");
    const emailDisplay = document.getElementById("emailDisplay");
    const userEmailElement = document.getElementById("userEmail");

    if (document.location == "http://localhost:3000/profile.html") {
        if (userEmail) {
            emailDisplay.textContent = userEmail;
            userEmailElement.textContent = userEmail;
        } else {
            alert("Você não está logado.");
            window.location.href = "./index.html";
        }
    }

    if (formAtualizar) {
        formAtualizar.addEventListener("submit", async (e) => {
            e.preventDefault();

            const novoEmail = document.getElementById("novoEmail").value;
            const novaSenha = document.getElementById("novaSenha").value;

            if (!novoEmail && !novaSenha) {
                alert();
                return;
            }

            try {
                const res = await fetch('http://localhost:3000/atualizar', {
                    method: "PUT",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        email: userEmail,
                        senha: novaSenha,
                        novoEmail: novoEmail
                    })
                });

                const data = await res.json();
                if (res.status === 200) {
                    alert(`OK: ${data.mensagem}`);
                    if (novoEmail) {
                        localStorage.setItem("userEmail", novoEmail);
                        window.location.reload();
                    }
                } else {
                    alert(`ERROR: ${data.mensagem}`);
                }
            } catch (error) {
                alert("Erro ao conectar com o servidor");
                console.error(error);
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const cadeiras = document.querySelectorAll('.cadeira');
    const btnComprar = document.getElementById('btnComprar');
   
    const imgOcupado = "../frontend/public/banco/seubanco.png";

   
    cadeiras.forEach(cadeira => {
        cadeira.addEventListener('click', () => {
   
            if (!cadeira.classList.contains('cadeiraocupada')) {
                cadeira.classList.toggle('selecionada');
            }
        });
    });


    btnComprar.addEventListener('click', () => {
        const selecionadas = document.querySelectorAll('.cadeira.selecionada');

        if (selecionadas.length === 0) {
            alert("Selecione pelo menos uma cadeira.");
            return;
        }

        selecionadas.forEach(cadeira => {
     
            cadeira.src = imgOcupado;

            cadeira.classList.remove('selecionada');
            cadeira.classList.add('cadeiraocupada');

            cadeira.classList.remove('cadeira');
        });

        alert("Compra realizada com sucesso!");
    });
});
